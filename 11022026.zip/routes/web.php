<?php

use App\Http\Controllers\DashboardController;
use App\Http\Controllers\ProfileController;

// Default Route
Route::get('/', function () {
    return view('welcome');
});

// Dashboard Routes with Middleware
Route::get('/dashboard', [DashboardController::class, 'index'])->middleware(['auth', 'verified'])->name('dashboard');
Route::get('/dashboard-large', [DashboardController::class, 'large'])->middleware(['auth', 'verified'])->name('dashboard.large');
Route::get('/dashboard-portrait', [DashboardController::class, 'portrait'])->middleware(['auth', 'verified'])->name('dashboard.portrait');

// Dashboard Settings Routes (Admin only)
Route::middleware(['auth', 'verified'])->group(function () {
    Route::get('/dashboard-settings', [\App\Http\Controllers\DashboardSettingsController::class, 'index'])->name('dashboard-settings.index');
    Route::post('/dashboard-settings', [\App\Http\Controllers\DashboardSettingsController::class, 'update'])->name('dashboard-settings.update');
});

// Profile Routes with Middleware
Route::middleware('auth')->group(function () {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
    
    // Include modular route files
    require __DIR__.'/location.php';
    require __DIR__.'/machinary.php';
    require __DIR__.'/downtime.php';
    require __DIR__.'/production.php';
    require __DIR__.'/users.php';
    require __DIR__.'/preventive-maintenance.php';
    require __DIR__.'/predictive-maintenance.php';
    require __DIR__.'/reports.php';
    require __DIR__.'/standards.php';
    require __DIR__.'/admin.php';
    require __DIR__.'/inspections.php';
});

// Contact Form Route
Route::post('/contact', [\App\Http\Controllers\ContactController::class, 'send'])->name('contact.send');

// Photo Routes (public access for viewing, auth required for upload/delete)
Route::get('/photos/{id}', [\App\Http\Controllers\PhotoController::class, 'show'])->name('photos.show');
Route::get('/photos/{id}/download', [\App\Http\Controllers\PhotoController::class, 'download'])->name('photos.download');
Route::middleware('auth')->group(function () {
    Route::post('/photos/upload', [\App\Http\Controllers\PhotoController::class, 'upload'])->name('photos.upload');
    Route::delete('/photos/{id}', [\App\Http\Controllers\PhotoController::class, 'destroy'])->name('photos.destroy');
});

// Authentication Routes
require __DIR__.'/auth.php';
